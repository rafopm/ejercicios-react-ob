import React from "react";
import Conctact from "./Conctact";

const ContactDeatil = () => {
  return <Conctact nombre="Luis" apellido="Lopez" email="luis@email.com" conectado={false} />;
};

export default ContactDeatil;
