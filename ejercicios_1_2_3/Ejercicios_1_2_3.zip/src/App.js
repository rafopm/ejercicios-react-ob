import ContactDeatil from './components/ContactDeatil';

function App() {
  return (
    <div className="App">
      Hola Mundo
      <ContactDeatil />
    </div>
  );
}

export default App;
