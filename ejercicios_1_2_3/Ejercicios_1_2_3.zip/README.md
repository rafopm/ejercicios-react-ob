Ejercicio 1, 2 y 3 Open Bootcamp </br>
![Preview](./public/capture.png)